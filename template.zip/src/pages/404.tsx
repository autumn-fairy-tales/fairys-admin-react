import { ErrorPage404 } from '@fairys/admin-tools-react';

function Page404() {
  return <ErrorPage404 />;
}
export const Component = Page404;
export default Component;
