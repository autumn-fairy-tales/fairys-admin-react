import { Layout } from '@fairys/admin-tools-react';

export const Component = Layout;
export default Component;
