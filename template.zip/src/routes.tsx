import type { RouteObject } from 'react-router';
import routesData from '@fairys:routes';

export const routes: RouteObject[] = [...routesData];
